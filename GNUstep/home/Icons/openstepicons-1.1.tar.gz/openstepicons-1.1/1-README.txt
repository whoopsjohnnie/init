: "OPENSTEP SYSTEM" 48x48 Icon Pak v1.0
: Released By John T. Folden (jtfolden@erinet.com) 10.20.2000


Included within are 48x48 sized icons from

OPENSTEP 4.x for Mach
OPENSTEP Enterprise 4.x for NT
OPENSTEP 4.x for Solaris
OPENSTEP v4.0  DR1 - "Experimental User Interface" release

While the majority of icons have been recreated as perfectly
as possible from the originals, a few of unusually large demensions
have been resized or modified for use at 48x48. I've appended
"-jtf" to the end of the filename on most of these.

Be on the lookout for other icon paks appearing shortly.



Enjoy!

John T. Folden
http://www.thejagcompany.com/jtfolden/NeXTVIEW/ - The NeXTVIEW

; NOTE: PLEASE GIVE CREDIT WHERE CREDIT IS DUE IF YOU 'BORROW' ANY PORTION
; OF THIS COLLECTION. I MAKE NO CLAIMS OF OWNERSHIP TO THE ORIGINAL IMAGES
; THE ICONS CONTAINED WITHIN WERE BASED ON (that goes to NeXT/Apple)
; -HOWEVER- AS A SIGN OF RESPECT FOR THE HARD LABOR IT TAKES TO CONVERT
; THESE LITTLE WORKS OF ART FROM THEIR ORIGINAL TIFF FORMAT, IF YOU DECIDE TO
; USE ANY OF THEM IN A PUBLIC THEME, ETC... IT WOULD BE GREATLY APPRECIATED
; IF YOU WOULD INCLUDE A MENTION OF WHERE YOU RECEIVED THEM.  THANKS!

; I WOULD ALSO APPRECIATE IT IF THIS COLLECTION WAS NOT UPLOADED TO OTHER SITES,
; ETC... AND THAT NO DIRECT LINKS WERE MADE TO THIS ARCHIVE. LINKING TO THE
; MAIN SITE LISTED ABOVE IS FINE.





